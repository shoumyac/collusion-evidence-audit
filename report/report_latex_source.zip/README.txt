Compile from the report folder: cd report && pdflatex report.tex && pdflatex report.tex
